<?php
define("U","admin");
define("P","an4989452");
?>